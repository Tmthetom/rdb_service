Drop procedure sp_connectScenario
go
Drop procedure sp_connectSection
go
Drop procedure sp_connectCheck
go
Drop procedure sp_connectOperation
go
