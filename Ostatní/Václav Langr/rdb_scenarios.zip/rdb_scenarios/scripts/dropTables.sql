Drop table [scenario_checks] 
go
Drop table [scenario_contains] 
go
Drop table [section_contains] 
go
Drop table [check_contains] 
go
Drop table [scenario_attributes] 
go
Drop table [section_attributes] 
go
Drop table [check_attributes] 
go
Drop table [operation_contains] 
go
Drop table [operation_attributes] 
go
Drop table [check_operations] 
go
Drop table [check_point] 
go
Drop table [scenario] 
go
Drop table [section] 
go
Drop table [operation] 
go